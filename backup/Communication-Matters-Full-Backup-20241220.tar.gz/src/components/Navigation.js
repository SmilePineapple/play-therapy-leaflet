import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAccessibility } from '../contexts/AccessibilityContext';

const Navigation = () => {
  const location = useLocation();
  const { announce, handleKeyboardNavigation } = useAccessibility();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigationItems = [
    { path: '/', label: 'Home', icon: '🏠', description: 'Conference home page' },
    { path: '/programme', label: 'Programme', icon: '📅', description: 'Conference schedule and sessions' },
    { path: '/my-agenda', label: 'My Agenda', icon: '⭐', description: 'Your bookmarked sessions' },
    { path: '/map', label: 'Map', icon: '🗺️', description: 'Venue map and directions' },
    { path: '/announcements', label: 'News', icon: '📢', description: 'Latest announcements' },
    { path: '/qa', label: 'Q&A', icon: '❓', description: 'Questions and answers' },
    { path: '/sponsors', label: 'Sponsors', icon: '🏢', description: 'Conference sponsors' }
  ];

  const toggleMobileMenu = () => {
    const newState = !mobileMenuOpen;
    setMobileMenuOpen(newState);
    announce(`Mobile menu ${newState ? 'opened' : 'closed'}`);
  };

  const handleNavClick = (item) => {
    setMobileMenuOpen(false);
    announce(`Navigating to ${item.label}`);
  };

  const handleKeyDown = (event, item) => {
    handleKeyboardNavigation(event, {
      onEnter: () => handleNavClick(item),
      onEscape: () => {
        if (mobileMenuOpen) {
          setMobileMenuOpen(false);
          announce('Mobile menu closed');
        }
      }
    });
  };

  return (
    <nav className="navigation" role="navigation" aria-label="Main navigation">
      <div className="container">
        {/* Mobile Menu Button */}
        <button
          className="mobile-menu-button"
          onClick={toggleMobileMenu}
          aria-expanded={mobileMenuOpen}
          aria-controls="main-nav-list"
          aria-label="Toggle navigation menu"
        >
          <span className="hamburger-icon" aria-hidden="true">
            <span></span>
            <span></span>
            <span></span>
          </span>
          <span className="mobile-menu-text">
            {mobileMenuOpen ? 'Close Menu' : 'Menu'}
          </span>
        </button>

        {/* Navigation List */}
        <ul 
          id="main-nav-list"
          className={`nav-list ${mobileMenuOpen ? 'mobile-open' : ''}`}
          role="menubar"
        >
          {navigationItems.map((item, index) => {
            const isActive = location.pathname === item.path;
            
            return (
              <li key={item.path} className="nav-item" role="none">
                <Link
                  to={item.path}
                  className={`nav-link ${isActive ? 'active' : ''}`}
                  onClick={() => handleNavClick(item)}
                  onKeyDown={(e) => handleKeyDown(e, item)}
                  role="menuitem"
                  aria-current={isActive ? 'page' : undefined}
                  aria-describedby={`nav-desc-${index}`}
                  tabIndex={mobileMenuOpen || window.innerWidth > 768 ? 0 : -1}
                >
                  <span className="nav-icon" aria-hidden="true">{item.icon}</span>
                  <span className="nav-text">{item.label}</span>
                  {isActive && <span className="sr-only">(current page)</span>}
                </Link>
                <div id={`nav-desc-${index}`} className="sr-only">
                  {item.description}
                </div>
              </li>
            );
          })}
        </ul>
      </div>

    </nav>
  );
};

export default Navigation;
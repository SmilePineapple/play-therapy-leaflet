import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAccessibility } from '../contexts/AccessibilityContext';
import { dbHelpers } from '../lib/supabase';
import { mockSessions } from '../data/mockSessions';

const Programme = () => {
  const { announce, focusFirstHeading } = useAccessibility();
  const [sessions, setSessions] = useState([]);
  const [filteredSessions, setFilteredSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    day: 'all',
    track: 'all',
    search: ''
  });
  const [bookmarkedSessions, setBookmarkedSessions] = useState([]);

  const loadSessions = useCallback(async () => {
    try {
      // Try to load from Supabase first, fallback to mock data
      const { data, error } = await dbHelpers.getSessions();
      
      let sessionsData;
      if (error || !data || data.length === 0) {
        sessionsData = mockSessions;
        announce('Conference programme loaded from local data');
      } else {
        sessionsData = data;
        announce('Conference programme loaded from database');
      }
      
      // Sort sessions by date and time
      const sortedSessions = (sessionsData || []).sort((a, b) => {
        const dateA = new Date(a.start_time);
        const dateB = new Date(b.start_time);
        return dateA - dateB;
      });
      
      setSessions(sortedSessions);
      
    } catch (error) {
      console.error('❌ Error loading sessions, using mock data:', error);
      setSessions(mockSessions);
      announce('Conference programme loaded from local data');
    } finally {
      setLoading(false);
    }
  }, [announce]);

  const loadBookmarks = useCallback(async () => {
    try {
      const { data: bookmarkIds, error } = await dbHelpers.getUserBookmarks();
      if (error) {
        console.error('❌ Error loading bookmarks from Supabase:', error);
        setBookmarkedSessions([]);
        return;
      }
      
      setBookmarkedSessions(Array.isArray(bookmarkIds) ? bookmarkIds : []);
    } catch (error) {
      console.error('❌ Error loading bookmarks:', error);
      setBookmarkedSessions([]);
    }
  }, []);

  const applyFilters = useCallback(() => {
    let filtered = [...sessions];
    
    // Filter by day
    if (filters.day !== 'all') {
      filtered = filtered.filter(session => {
        const sessionDate = new Date(session.start_time).toDateString();
        return sessionDate === filters.day;
      });
    }
    
    // Filter by track
    if (filters.track !== 'all') {
      filtered = filtered.filter(session => 
        session.track?.toLowerCase() === filters.track.toLowerCase()
      );
    }
    
    // Filter by search
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      filtered = filtered.filter(session => 
        session.title?.toLowerCase().includes(searchTerm) ||
        session.abstract?.toLowerCase().includes(searchTerm) ||
        session.speaker?.toLowerCase().includes(searchTerm) ||
        session.category?.toLowerCase().includes(searchTerm)
      );
    }
    
    setFilteredSessions(filtered);
    
    // Announce filter results
    const resultCount = filtered.length;
    announce(`${resultCount} session${resultCount !== 1 ? 's' : ''} found`);
  }, [sessions, filters, announce]);

  useEffect(() => {
    const initializePage = async () => {
      focusFirstHeading();
      announce('Programme page loaded');
      
      await loadSessions();
      await loadBookmarks();
    };
    
    initializePage();
  }, [announce, focusFirstHeading, loadSessions, loadBookmarks]);

  useEffect(() => {
    applyFilters();
  }, [applyFilters]);

  const toggleBookmark = async (sessionId) => {
    const isCurrentlyBookmarked = bookmarkedSessions.includes(sessionId);
    
    try {
      let result;
      if (isCurrentlyBookmarked) {
        result = await dbHelpers.removeBookmark(sessionId);
      } else {
        result = await dbHelpers.addBookmark(sessionId);
      }
      
      if (result.error) {
        console.error('❌ Error toggling bookmark:', result.error);
        return;
      }
      
      // Update local state only if Supabase operation succeeded
      setBookmarkedSessions(prev => {
        if (isCurrentlyBookmarked) {
          const newBookmarks = prev.filter(id => id !== sessionId);
          return newBookmarks;
        } else {
          const newBookmarks = [...prev, sessionId];
          return newBookmarks;
        }
      });
      
    } catch (error) {
      console.error('❌ Error toggling bookmark:', error);
    }
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
  };

  const clearFilters = () => {
    setFilters({ day: 'all', track: 'all', search: '' });
    announce('Filters cleared');
  };

  // Get unique days and tracks for filter options
  const uniqueDays = [...new Set(sessions.map(session => 
    new Date(session.start_time).toDateString()
  ))].sort();
  
  const uniqueTracks = [...new Set(sessions.map(session => session.track).filter(Boolean))].sort();

  const formatTime = (dateString) => {
    return new Date(dateString).toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'long'
    });
  };

  if (loading) {
    return (
      <div className="container" style={{ padding: 'var(--spacing-xl) var(--spacing-md)' }}>
        <div className="loading-content" role="status" aria-live="polite">
          <h1>Loading Conference Programme...</h1>
          <div className="loading-spinner" aria-hidden="true"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="programme-page">
      <div className="container">
        <header className="page-header">
          <h1>Conference Programme</h1>
          <p className="page-description">
            Browse all conference sessions, bookmark your favorites, and build your personal agenda.
          </p>
        </header>

        {/* Filters */}
        <section className="filters-section" aria-labelledby="filters-title">
          <h2 id="filters-title" className="sr-only">Filter Sessions</h2>
          
          <div className="filters-grid">
            {/* Search */}
            <div className="filter-group">
              <label htmlFor="search-input" className="filter-label">
                Search Sessions
              </label>
              <input
                id="search-input"
                type="text"
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                placeholder="Search by title, description, or speaker..."
                className="filter-input"
                aria-describedby="search-help"
              />
              <div id="search-help" className="sr-only">
                Search through session titles, descriptions, and speaker names
              </div>
            </div>

            {/* Day Filter */}
            <div className="filter-group">
              <label htmlFor="day-filter" className="filter-label">
                Conference Day
              </label>
              <select
                id="day-filter"
                value={filters.day}
                onChange={(e) => handleFilterChange('day', e.target.value)}
                className="filter-select"
              >
                <option value="all">All Days</option>
                {uniqueDays.map(day => (
                  <option key={day} value={day}>
                    {formatDate(day)}
                  </option>
                ))}
              </select>
            </div>

            {/* Track Filter */}
            <div className="filter-group">
              <label htmlFor="track-filter" className="filter-label">
                Session Track
              </label>
              <select
                id="track-filter"
                value={filters.track}
                onChange={(e) => handleFilterChange('track', e.target.value)}
                className="filter-select"
              >
                <option value="all">All Tracks</option>
                {uniqueTracks.map(track => (
                  <option key={track} value={track}>
                    {track}
                  </option>
                ))}
              </select>
            </div>

            {/* Clear Filters */}
            <div className="filter-group">
              <button
                onClick={clearFilters}
                className="btn btn-outline"
                disabled={filters.day === 'all' && filters.track === 'all' && !filters.search}
              >
                Clear Filters
              </button>
            </div>
          </div>

          {/* Results Count */}
          <div className="results-info" role="status" aria-live="polite">
            Showing {filteredSessions.length} of {sessions.length} sessions
          </div>
        </section>

        {/* Sessions List */}
        <section className="sessions-section" aria-labelledby="sessions-title">
          <h2 id="sessions-title" className="sr-only">Session List</h2>
          
          {filteredSessions.length === 0 ? (
            <div className="no-results" role="status">
              <h3>No sessions found</h3>
              <p>Try adjusting your filters or search terms.</p>
              <button onClick={clearFilters} className="btn btn-primary">
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className="sessions-list">
              {filteredSessions.map((session) => {
                const isBookmarked = bookmarkedSessions.includes(session.id);
                
                return (
                  <article key={session.id} className="session-card">
                    <div className="session-time">
                      <time dateTime={session.start_time}>
                        <span className="session-date">
                          {formatDate(session.start_time)}
                        </span>
                        <span className="session-time-range">
                          {session.time || `${formatTime(session.start_time)} - ${formatTime(new Date(new Date(session.start_time).getTime() + 45 * 60000))}`}
                        </span>
                      </time>
                      {session.location && (
                        <div className="session-location">
                          📍 {session.location}
                        </div>
                      )}
                    </div>

                    <div className="session-content">
                      <div className="session-header">
                        <h3 className="session-title">
                          <Link to={`/session/${session.id}`}>
                            {session.title}
                          </Link>
                        </h3>
                        {session.track && (
                          <span className="session-track">{session.track}</span>
                        )}
                      </div>

                      {session.speaker && (
                        <div className="session-speakers">
                          <span className="speakers-label">Speaker(s):</span>
                          <span className="speaker-name">{session.speaker}</span>
                        </div>
                      )}

                      {session.category && (
                        <div className="session-category">
                          <span className="category-label">Category:</span>
                          <span className="category-name">{session.category}</span>
                        </div>
                      )}

                      {session.abstract && (
                        <p className="session-description">
                          {session.abstract.length > 200 
                            ? `${session.abstract.substring(0, 200)}...` 
                            : session.abstract
                          }
                        </p>
                      )}

                      <div className="session-actions">
                        <Link 
                          to={`/session/${session.id}`} 
                          className="btn btn-primary"
                          onClick={() => announce(`Viewing details for ${session.title}`)}
                        >
                          View Details
                        </Link>
                        
                        <button
                          onClick={() => toggleBookmark(session.id)}
                          className={`btn ${isBookmarked ? 'btn-secondary' : 'btn-outline'}`}
                          aria-pressed={isBookmarked}
                          title={isBookmarked ? 'Remove from agenda' : 'Add to agenda'}
                        >
                          <span aria-hidden="true">
                            {isBookmarked ? '⭐' : '☆'}
                          </span>
                          {isBookmarked ? 'In Agenda' : 'Add to Agenda'}
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </div>

    </div>
  );
};

export default Programme;
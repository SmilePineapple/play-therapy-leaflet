import React, { useState, useEffect, useCallback } from 'react';
import { useAccessibility } from '../contexts/AccessibilityContext';
import { dbHelpers } from '../lib/supabase';
import Loading from '../components/Loading';
import styles from './Sponsors.module.css';

const Sponsors = () => {
  const { announce, focusFirstHeading } = useAccessibility();
  const [sponsors, setSponsors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // 'all', 'platinum', 'gold', 'silver', 'bronze', 'partner'
  const [selectedSponsor, setSelectedSponsor] = useState(null);

  const loadSponsors = useCallback(async () => {
    try {
      const { data, error } = await dbHelpers.getSponsors();
      
      if (error) {
        console.error('❌ Error loading sponsors:', error);
        announce('Error loading sponsors');
        return;
      }
      
      // Sort sponsors by tier and name
      const tierOrder = { 'platinum': 1, 'gold': 2, 'silver': 3, 'bronze': 4, 'partner': 5, 'supporter': 6 };
      const sortedSponsors = (data || []).sort((a, b) => {
        const tierDiff = (tierOrder[a.tier] || 99) - (tierOrder[b.tier] || 99);
        if (tierDiff !== 0) {
          return tierDiff;
        }
        return a.name.localeCompare(b.name);
      });
      
      setSponsors(sortedSponsors);
      
    } catch (error) {
      console.error('❌ Error loading sponsors:', error);
      announce('Error loading sponsors');
    } finally {
      setLoading(false);
    }
  }, [announce]);

  useEffect(() => {
    focusFirstHeading();
    announce('Conference sponsors and partners page loaded');
    
    loadSponsors();
  }, [focusFirstHeading, announce, loadSponsors]);

  const openSponsorDetails = (sponsor) => {
    setSelectedSponsor(sponsor);
    announce(`Opened details for ${sponsor.name}`);
  };

  const closeSponsorDetails = () => {
    setSelectedSponsor(null);
    announce('Closed sponsor details');
  };

  // Filter sponsors based on selected tier
  const filteredSponsors = sponsors.filter(sponsor => {
    if (filter === 'all') {
      return true;
    }
    return sponsor.tier === filter;
  });

  // Group sponsors by tier for display
  const sponsorsByTier = filteredSponsors.reduce((acc, sponsor) => {
    if (!acc[sponsor.tier]) {
      acc[sponsor.tier] = [];
    }
    acc[sponsor.tier].push(sponsor);
    return acc;
  }, {});

  const getTierInfo = (tier) => {
    const tierData = {
      platinum: { name: 'Platinum Sponsors', icon: '💎', color: '#E5E4E2', description: 'Our premier partners' },
      gold: { name: 'Gold Sponsors', icon: '🥇', color: '#FFD700', description: 'Major supporters' },
      silver: { name: 'Silver Sponsors', icon: '🥈', color: '#C0C0C0', description: 'Valued partners' },
      bronze: { name: 'Bronze Sponsors', icon: '🥉', color: '#CD7F32', description: 'Supporting partners' },
      partner: { name: 'Partners', icon: '🤝', color: '#4CAF50', description: 'Collaborative partners' },
      supporter: { name: 'Supporters', icon: '👏', color: '#2196F3', description: 'Community supporters' }
    };
    return tierData[tier] || { name: tier, icon: '🏢', color: '#666', description: 'Sponsors' };
  };

  const getSponsorCardSize = (tier) => {
    switch (tier) {
      case 'platinum': return 'large';
      case 'gold': return 'medium';
      case 'silver': return 'small';
      case 'bronze': return 'small';
      default: return 'small';
    }
  };

  if (loading) {
    return <Loading message="Loading Sponsors..." />;
  }

  return (
    <div className={styles.sponsorsPage}>
      <div className="container">
        <header className={styles.pageHeader}>
          <h1>Conference Sponsors & Partners</h1>
          <p className={styles.pageDescription}>
            We&apos;re grateful to our sponsors and partners who make the Communication Matters Conference possible.
            Their support enables us to provide accessible, high-quality content and experiences.
          </p>
        </header>

        {/* Summary Stats */}
        <section className={styles.sponsorsStats} aria-labelledby="stats-title">
          <h2 id="stats-title" className="sr-only">Sponsor Statistics</h2>
          <div className={styles.statsGrid}>
            <div className={styles.statCard}>
              <span className={styles.statNumber}>{sponsors.length}</span>
              <span className={styles.statLabel}>Total Sponsors</span>
            </div>
            <div className={styles.statCard}>
              <span className={styles.statNumber}>{sponsors.filter(s => s.tier === 'platinum' || s.tier === 'gold').length}</span>
              <span className={styles.statLabel}>Major Sponsors</span>
            </div>
            <div className={styles.statCard}>
              <span className={styles.statNumber}>{sponsors.filter(s => s.tier === 'partner').length}</span>
              <span className={styles.statLabel}>Partners</span>
            </div>
          </div>
        </section>

        {/* Thank You Message */}
        <section className={styles.thankYouSection}>
          <div className={styles.thankYouCard}>
            <h2>🙏 Thank You to Our Sponsors</h2>
            <p>
              The Communication Matters Conference is made possible through the generous support of our sponsors and partners. 
              Their commitment to advancing AAC research, technology, and practice helps us create an inclusive and 
              accessible event for all participants.
            </p>
          </div>
        </section>

        {/* Filter Controls */}
        <section className={styles.sponsorsControls} aria-labelledby="controls-title">
          <h2 id="controls-title" className="sr-only">Filter Sponsors</h2>
          
          <div className="filter-group">
            <fieldset className={styles.filterFieldset}>
              <legend className={styles.filterLegend}>Filter by Sponsor Level</legend>
              <div className={styles.filterButtons}>
                {[
                  { value: 'all', label: 'All Sponsors', icon: '🏢' },
                  { value: 'platinum', label: 'Platinum', icon: '💎' },
                  { value: 'gold', label: 'Gold', icon: '🥇' },
                  { value: 'silver', label: 'Silver', icon: '🥈' },
                  { value: 'bronze', label: 'Bronze', icon: '🥉' },
                  { value: 'partner', label: 'Partners', icon: '🤝' }
                ].map(filterOption => (
                  <button
                    key={filterOption.value}
                    onClick={() => setFilter(filterOption.value)}
                    className={`${styles.filterBtn} ${filter === filterOption.value ? styles.active : ''}`}
                    aria-pressed={filter === filterOption.value}
                  >
                    <span aria-hidden="true">{filterOption.icon}</span>
                    {filterOption.label}
                  </button>
                ))}
              </div>
            </fieldset>
          </div>

          {/* Results Info */}
          <div className={styles.resultsInfo} role="status" aria-live="polite">
            Showing {filteredSponsors.length} sponsor{filteredSponsors.length !== 1 ? 's' : ''}
          </div>
        </section>

        {/* Sponsors by Tier */}
        <section className="sponsors-section" aria-labelledby="sponsors-title">
          <h2 id="sponsors-title" className="sr-only">Sponsors List</h2>
          
          {Object.keys(sponsorsByTier).length === 0 ? (
            <div className={styles.noSponsors}>
              <h3>No sponsors found</h3>
              <p>No sponsors match your current filter.</p>
              <button onClick={() => setFilter('all')} className="btn btn-primary">
                Show All Sponsors
              </button>
            </div>
          ) : (
            <div className={styles.sponsorsTiers}>
              {Object.entries(sponsorsByTier).map(([tier, tierSponsors]) => {
                const tierInfo = getTierInfo(tier);
                
                return (
                  <div key={tier} className={styles.sponsorTier}>
                    <header className={styles.tierHeader}>
                      <h3 className={styles.tierTitle}>
                        <span className={styles.tierIcon} aria-hidden="true">{tierInfo.icon}</span>
                        {tierInfo.name}
                      </h3>
                      <p className={styles.tierDescription}>{tierInfo.description}</p>
                      <div className={styles.tierCount}>
                        {tierSponsors.length} sponsor{tierSponsors.length !== 1 ? 's' : ''}
                      </div>
                    </header>
                    
                    <div className={`${styles.sponsorsGrid} ${styles[getSponsorCardSize(tier)]}`}>
                      {tierSponsors.map((sponsor) => (
                        <article key={sponsor.id} className={styles.sponsorCard}>
                          <div className={styles.sponsorContent}>
                            {sponsor.logo_url ? (
                              <div className={styles.sponsorLogo}>
                                <img 
                                  src={sponsor.logo_url} 
                                  alt={`${sponsor.name} logo`}
                                  onError={(e) => {
                                    e.target.style.display = 'none';
                                    e.target.nextSibling.style.display = 'flex';
                                  }}
                                />
                                <div className={styles.logoFallback} style={{ display: 'none' }}>
                                  <span className={styles.fallbackIcon}>🏢</span>
                                  <span className={styles.fallbackText}>{sponsor.name}</span>
                                </div>
                              </div>
                            ) : (
                              <div className={styles.sponsorLogo}>
                                <div className={styles.logoFallback}>
                                  <span className={styles.fallbackIcon}>🏢</span>
                                  <span className={styles.fallbackText}>{sponsor.name}</span>
                                </div>
                              </div>
                            )}
                            
                            <div className={styles.sponsorInfo}>
                              <h4 className={styles.sponsorName}>{sponsor.name}</h4>
                              
                              {sponsor.tagline && (
                                <p className={styles.sponsorTagline}>{sponsor.tagline}</p>
                              )}
                              
                              {sponsor.description && (
                                <p className={styles.sponsorDescription}>
                                  {sponsor.description.length > 100 
                                    ? `${sponsor.description.substring(0, 100)}...` 
                                    : sponsor.description}
                                </p>
                              )}
                            </div>
                          </div>
                          
                          <footer className={styles.sponsorActions}>
                            {sponsor.website_url && (
                              <a 
                                href={sponsor.website_url} 
                                className={`btn btn-outline ${styles.btnSm}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label={`Visit ${sponsor.name} website`}
                              >
                                🌐 Website
                              </a>
                            )}
                            
                            <button
                              onClick={() => openSponsorDetails(sponsor)}
                              className={`btn btn-primary ${styles.btnSm}`}
                              aria-label={`View details for ${sponsor.name}`}
                            >
                              📋 Details
                            </button>
                          </footer>
                        </article>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Become a Sponsor CTA */}
        <section className={styles.becomeSponsorSection}>
          <div className={styles.ctaCard}>
            <h2>🤝 Become a Sponsor</h2>
            <p>
              Interested in supporting the Communication Matters Conference? 
              We offer various sponsorship opportunities to help you connect with the AAC community.
            </p>
            <div className={styles.ctaActions}>
              <a href="mailto:sponsors@communicationmatters.org.uk" className="btn btn-primary">
                📧 Contact Us
              </a>
              <a href="/sponsorship-info.pdf" className="btn btn-outline" target="_blank" rel="noopener noreferrer">
                📄 Sponsorship Info
              </a>
            </div>
          </div>
        </section>
      </div>

      {/* Sponsor Details Modal */}
      {selectedSponsor && (
        <div className={styles.modalOverlay} onClick={closeSponsorDetails}>
          <div className={styles.modalContent} onClick={(e) => e.stopPropagation()} role="dialog" aria-labelledby="modal-title" aria-modal="true">
            <header className={styles.modalHeader}>
              <h2 id="modal-title">{selectedSponsor.name}</h2>
              <button 
                onClick={closeSponsorDetails}
                className={styles.modalClose}
                aria-label="Close sponsor details"
              >
                ✕
              </button>
            </header>
            
            <div className={styles.modalBody}>
              {selectedSponsor.logo_url && (
                <div className={styles.modalLogo}>
                  <img src={selectedSponsor.logo_url} alt={`${selectedSponsor.name} logo`} />
                </div>
              )}
              
              <div className={styles.modalInfo}>
                <div className={styles.sponsorTierBadge}>
                  <span className={styles.tierIcon}>{getTierInfo(selectedSponsor.tier).icon}</span>
                  {getTierInfo(selectedSponsor.tier).name}
                </div>
                
                {selectedSponsor.tagline && (
                  <p className={styles.modalTagline}>{selectedSponsor.tagline}</p>
                )}
                
                {selectedSponsor.description && (
                  <div className={styles.modalDescription}>
                    <h3>About {selectedSponsor.name}</h3>
                    <p>{selectedSponsor.description}</p>
                  </div>
                )}
                
                {selectedSponsor.products && (
                  <div className={styles.modalProducts}>
                    <h3>Products & Services</h3>
                    <p>{selectedSponsor.products}</p>
                  </div>
                )}
                
                {selectedSponsor.contact_info && (
                  <div className={styles.modalContact}>
                    <h3>Contact Information</h3>
                    <p>{selectedSponsor.contact_info}</p>
                  </div>
                )}
              </div>
            </div>
            
            <footer className={styles.modalFooter}>
              {selectedSponsor.website_url && (
                <a 
                  href={selectedSponsor.website_url} 
                  className="btn btn-primary"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  🌐 Visit Website
                </a>
              )}
              
              {selectedSponsor.social_media && (
                <div className={styles.socialLinks}>
                  {selectedSponsor.social_media.twitter && (
                    <a href={selectedSponsor.social_media.twitter} target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                      🐦
                    </a>
                  )}
                  {selectedSponsor.social_media.linkedin && (
                    <a href={selectedSponsor.social_media.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                      💼
                    </a>
                  )}
                  {selectedSponsor.social_media.facebook && (
                    <a href={selectedSponsor.social_media.facebook} target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                      📘
                    </a>
                  )}
                </div>
              )}
            </footer>
          </div>
        </div>
      )}

    </div>
  );
};

export default Sponsors;